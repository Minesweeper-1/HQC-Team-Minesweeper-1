﻿namespace Minesweeper.UI.Wpf.InputProviders.Contracts
{
    using Logic.InputProviders.Contracts;

    public interface IWpfInputProvider : IInputProvider
    {
    }
}
