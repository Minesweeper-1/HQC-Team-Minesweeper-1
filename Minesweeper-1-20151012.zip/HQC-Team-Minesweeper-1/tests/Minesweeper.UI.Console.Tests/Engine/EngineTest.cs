﻿// <copyright file="EngineTest.cs" company="Team Minesweeper-1">
// Copyright (c) The team. All rights reserved.
// </copyright>
namespace Minesweeper.UI.Console.Tests.Engine
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// Test class for the Engine class
    /// </summary>
    [TestClass]
    public class EngineTest
    {
        /// <summary>
        /// This test method is not created yet
        /// </summary>
        [TestMethod]
        public void TestMethod1()
        {            
        }
    }
}
