﻿namespace Minesweeper.Logic.Tests.Borads
{
    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Minesweeper.Logic.Boards;
    using Boards.Settings.Contracts;

    [TestClass]
    public class BoardTests
    {
        [TestMethod]
        public void TestMethod1()
        {
            
        }
    }
}
